// creating an array and passing the number, questions, options, and answers
let questions = [
    {
    numb: 1,
    question: "Which type of JavaScript language is ___",
    answer: "Object-Based",
    options: [
      "Object-Oriented",
      "Object-Based",
      "Assembly-language",
      "High-level"
    ]
  },
    {
    numb: 2,
    question: "Which one of the following also known as Conditional Expression:",
    answer: "immediate if",
    options: [
      "Alternative to if-else",
      "Switch statement",
      "If-then-else statement",
      "immediate if"
    ]
  },
    {
      numb: 3,
      question: "When interpreter encounters an empty statements, what it will do:",
      answer: "Ignores the statements",
      options: [
        "Shows a warning",
        "Prompts to complete the statement",
        "Throws an error",
        "Ignores the statements"
      ]
  },
    {
    numb: 4,
    question: "The 'function' and 'var' are known as:",
    answer: "Declaration statements",
    options: [
      "Keywords",
      "Data types",
      "Declaration statements",
      "Prototypes"
    ]
  },
    {
    numb: 5,
    question: "Which of the following type of a variable is volatile?",
    answer: "Mutable variable",
    options: [
      "Mutable variable",
      "Dynamic variable",
      "Volatile variable",
      "Immutable variable"
    ]
  },
  // you can uncomment the below codes and make duplicate as more as you want to add question
  // but remember you need to give the numb value serialize like 1,2,3,5,6,7,8,9.....

  //   {
  //   numb: 6,
  //   question: "Your Question is Here",
  //   answer: "Correct answer of the question is here",
  //   options: [
  //     "Option 1",
  //     "option 2",
  //     "option 3",
  //     "option 4"
  //   ]
  // },
];